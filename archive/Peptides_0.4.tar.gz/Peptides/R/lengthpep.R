lengthpep<-function(seq){
  length(s2c(seq))
}