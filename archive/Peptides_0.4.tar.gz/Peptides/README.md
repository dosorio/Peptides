Peptides
========
R package to calculate indices and theoretical physicochemical properties of peptides and protein sequences

Install
-------
Peptides package v.0.2 is avalible on CRAN, for install just type:
```
install.packages("Peptides", dependencies=TRUE)
```

Authorship and license
----------------------
[D. Osorio](mailto:danielcamiloosorio@gmail.com), P. Rondón-Villarreal and R. Torres. *Peptides: Calculate indices and theoretical physicochemical properties of peptides and protein sequences.*, 2014. URL: http: //CRAN.R-project.org/package=Peptides. R Package Version 0.2. License:GPL≥2.
